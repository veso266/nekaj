<?php 
/**
 * Make a call to the open exchange API
 * 
 * @param $filename
 * What data to collect
 * 
 * @return
 * JSON Data
 */
function getOpenExchangeRates($filename){
		
	// Open CURL session:
	$ch = curl_init('http://denar.dxing.si/api/' . $filename);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	
	// Get the data:
	$json = curl_exec($ch);
	curl_close($ch);
	
	return json_decode($json);
}

/**
 * Get all the currency options
 * 
 * @param $default
 * Selected currency
 * 
 * @return
 * Echo the select options
 */
 
 
function getCurrencyOptions($default){
	
	$currencies = getOpenExchangeRates('currencies.json');
	
	foreach($currencies as $k => $v){
		$selected = '';

		if($k == $default){
			$selected = "selected='selected'";
		}	

		echo '<option '.$selected.' value="'.$k.'">'.$v.'</option>';	
	}
}
//getCurrencyOptions("SIT");
?>

<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="css/core.css">
<title>Convert Your Money</title>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
<script src="/js/money.js"></script>

<?php $exchangeRates = getOpenExchangeRates('latest.json'); ?>
<script type="text/javascript">
	fx.rates = <?php echo json_encode($exchangeRates->rates); ?>;
	fx.base = "<?php echo $exchangeRates->base; ?>";
</script>
<script src="css/core.js"></script>

</head>
<body>

<section class="container">

<div class="form">
	<h3>Exchange Currency</h3> 
	
	<p>From</p>
	<p><input type="text" name="money" id="money" value="100" /><select id="country_from">
			<?php getCurrencyOptions("EUR"); ?>
	</select></p>
	<p>To</p>
	<p> <input type="text" name="exchange_total" id="exchange_total" /><select id="country_to">
			<?php getCurrencyOptions("SIT"); ?>
	</select></p>
	<p> <input type="button" name="exchange" id="exchange" value="Exchange" /></p>
</div>

<script type="text/javascript">
$(document).ready(function(){
	$('#exchange').click(function(){		
		fx.settings = { from: $('#country_from').val(), to: $('#country_to').val() };
		var change = fx.convert($('#money').val());
		
		$('#exchange_total').val(change);
	});
});
</script>

</body>
</html>