<?php
echo "https://symfony.com/doc/current/security/api_key_authentication.html"
?>