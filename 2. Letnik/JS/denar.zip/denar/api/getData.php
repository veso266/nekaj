<?php 
/**
 * Make a call to the open exchange API
 * 
 * @param $filename
 * What data to collect
 * 
 * @return
 * JSON Data
 */
function getOpenExchangeRates($filename){
		
	// Open CURL session:
	$ch = curl_init('http://denar.dxing.si/api/' . $filename);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	
	// Get the data:
	$json = curl_exec($ch);
	curl_close($ch);
	
	return json_decode($json);
}

/**
 * Get all the currency options
 * 
 * @param $default
 * Selected currency
 * 
 * @return
 * Echo the select options
 */
 
 
function getCurrencyOptions($default){
	
	$currencies = getOpenExchangeRates('currencies.json');
	
	foreach($currencies as $k => $v){
		$selected = '';

		if($k == $default){
			$selected = "selected='selected'";
		}	

		echo '<option '.$selected.' value="'.$k.'">'.$v.'</option>';	
	}
}
//getCurrencyOptions("SIT");
echo "works";
?>