<?php
function sql_to_html_table($sqlresult, $delim="\n") {
  // starting table
  $htmltable =  "<style>a { color: black;  text-decoration: none;} table, th, td {    border: 1px solid black;    border-collapse: collapse;}</style>"."<table>" . $delim ;   
  $counter   = 0 ;
  // putting in lines
  while( $row = $sqlresult->fetch_assoc()  ){
    if ( $counter===0 ) {
      // table header
      $htmltable .=   "<tr>"  . $delim;
      foreach ($row as $key => $value ) {
          $htmltable .=   "<th>" .'<a href="/functions/sqlQuery.php?sort='.$key.'">'. $key . "</th>"  . $delim ;
      }
      $htmltable .=   "</tr>"  . $delim ; 
      $counter = 22;
    } 
      // table body
      $htmltable .=   "<tr>"  . $delim ;
      foreach ($row as $key => $value ) {
          $htmltable .=   "<td>" . $value . "</td>"  . $delim ;
      }
      $htmltable .=   "</tr>"   . $delim ;
  }
  // closing table
  $htmltable .=   "</table>"   . $delim ; 
  // return
  return( $htmltable ) ;
}
  
//Usage
//$DB = new mysqli("host", "username", "password", "database");
//$sqlresult = $DB->query( "SELECT * FROM testtable LIMIT 1 ;" ) ; 

//echo sql_to_html_table( $sqlresult, $delim="\n" ) ; 
//Usage
  
?>