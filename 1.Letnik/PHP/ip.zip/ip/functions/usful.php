<?php
//Function 1
function drawTable($rows, $cols){
echo "<table border='1'>"; 

for($tr=1;$tr<=$rows;$tr++){ 
     
    echo "<tr>"; 
        for($td=1;$td<=$cols;$td++){ 
               echo "<td align='center'>".$tr*$td."</td>"; 
        } 
    echo "</tr>"; 
} 

echo "</table>";
}
//Function 1



//Function 2
function table( $result ) {
    $result->fetch_array( MYSQLI_ASSOC );
    echo '<table>';
    tableHead( $result );
    tableBody( $result );
    echo '</table>';
}

function tableHead( $result ) {
    echo '<thead>';
    foreach ( $result as $x ) {
    echo '<tr>';
    foreach ( $x as $k => $y ) {
        echo '<th>' . ucfirst( $k ) . '</th>';
    }
    echo '</tr>';
    break;
    }
    echo '</thead>';
}

function tableBody( $result ) {
    echo '<tbody>';
    foreach ( $result as $x ) {
    echo '<tr>';
    foreach ( $x as $y ) {
        echo '<td>' . $y . '</td>';
    }
    echo '</tr>';
    }
    echo '</tbody>';
}
//Function 2

//Function 3
function sql_to_html_table($sqlresult, $delim="\n") {
  // starting table
  $htmltable =  "<style>table, th, td {    border: 1px solid black;    border-collapse: collapse;}</style>"."<table>" . $delim ;   
  $counter   = 0 ;
  // putting in lines
  while( $row = $sqlresult->fetch_assoc()  ){
    if ( $counter===0 ) {
      // table header
      $htmltable .=   "<tr>"  . $delim;
      foreach ($row as $key => $value ) {
          $htmltable .=   "<th>" . $key . "</th>"  . $delim ;
      }
      $htmltable .=   "</tr>"  . $delim ; 
      $counter = 22;
    } 
      // table body
      $htmltable .=   "<tr>"  . $delim ;
      foreach ($row as $key => $value ) {
          $htmltable .=   "<td>" . $value . "</td>"  . $delim ;
      }
      $htmltable .=   "</tr>"   . $delim ;
  }
  // closing table
  $htmltable .=   "</table>"   . $delim ; 
  // return
  return( $htmltable ) ; 
}
//Function 3
//Function 4
/**
 * Quick mysql result function
 *
 * @param $result
 * @return array
 */
function array_result($result)
{
    $args = array();
    while ($row = mysql_fetch_assoc($result)) {
        $args[] = $row;
    }
    return $args;
}



/**
 * Connect to db
 * 
 * @param string $db_host
 * @param string $db
 */
function db_connect($db_host = "localhost", $db = "apploymentdevs")
{
    $connect = mysql_connect($db_host,"root", "root");
    if (!$connect) {
        die(mysql_error());
    }
    mysql_select_db($db);
}

/**
 * Create a table from a result set
 *
 * @param array $results
 * @return string
 */
function createTable(array $results = array())
{
    if (empty($results)) {
        return '<table><tr><td>Empty Result Set</td></tr></table>';
    }

    // dynamically create the header information from the keys
    // of the result array from mysql
    $table = '<style>table, th, td {    border: 1px solid black;    border-collapse: collapse;}</style>'.'<table>';
    $keys = array_keys(reset($results));
    $table.='<thead><tr>';
    foreach ($keys as $key) {
        $table.='<th>'.$key.'</th>';
    }
    $table.='</tr></thead>';

    // populate the main table body
    $table.='<tbody>';
    foreach ($results as $result) {
        $table.='<tr>';
        foreach ($result as $val) {
            $table.='<td>'.$val.'</td>';
        }
        $table.='</tr>';
    }
    $table.='</tbody></table>';
    return $table;
}
//Function 4

//Usage Function 1
//drawTable(30, 10); --- This will create a table with 30 rows and 10 columns.
//Usage Function 1

//Usage Function 2
//table( $result );



//Usage Function 3
//$DB = new mysqli("host", "username", "password", "database");
//$sqlresult = $DB->query( "SELECT * FROM testtable LIMIT 1 ;" ) ; 

//echo sql_to_html_table( $sqlresult, $delim="\n" ) ; 
//Usage Function 3


//Usage Function 4
//db_connect();
	// assuming you have an auto increment id as the first column
//$result = mysql_query("SELECT * FROM demo ORDER BY 1 DESC LIMIT 10");
//print createTable(array_result($result));
//Usage Function 4

?>