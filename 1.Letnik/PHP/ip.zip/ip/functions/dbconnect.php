<?php
//DATABASE CONNECTION
$db_name = "veso266_ip";
$username = "veso266_ip";
$password = "Kokosja8";
$hostname = "localhost"; 
// Create connection
$conn = new mysqli($hostname, $username, $password, $db_name);
//DATABASE CONNECTION
//INSERT DATA
// TO POCNE PA DRUGI SKRIPTI
//INSERT DATA
?>