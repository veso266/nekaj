<?php
//https://stackoverflow.com/a/3489789 
require 'dbconnect.php';
require 'drawTable.php';
$sql = "SELECT * FROM iplogs";

if ($_GET['sort'] == 'id')
{
    $sql .= " ORDER BY id";
	$sqlresult = $conn->query($sql);
	echo sql_to_html_table( $sqlresult, $delim="\n" );
}
elseif ($_GET['sort'] == 'ip')
{
    $sql .= " ORDER BY ip";
	$sqlresult = $conn->query($sql);
	echo sql_to_html_table( $sqlresult, $delim="\n" );
}
elseif ($_GET['sort'] == 'Country')
{
    $sql .= " ORDER BY Country";
	$sqlresult = $conn->query($sql);
	echo sql_to_html_table( $sqlresult, $delim="\n" );
}
elseif ($_GET['sort'] == 'ISP')
{
    $sql .= " ORDER BY ISP";
	$sqlresult = $conn->query($sql);
	echo sql_to_html_table( $sqlresult, $delim="\n" );
}
elseif($_GET['sort'] == 'UserAgent')
{
    $sql .= " ORDER BY UserAgent";	
	$sqlresult = $conn->query($sql);
	echo sql_to_html_table( $sqlresult, $delim="\n" );
}
elseif($_GET['sort'] == 'Cas')
{
    $sql .= " ORDER BY Cas";	
	$sqlresult = $conn->query($sql);
	echo sql_to_html_table( $sqlresult, $delim="\n" );
}
?> 