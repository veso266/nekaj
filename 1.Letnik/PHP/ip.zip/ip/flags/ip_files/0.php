<?php
//-
$ranges=Array(
"0" => array("16777215","ZZ"),
"3452930" => array("",""),
);
?>