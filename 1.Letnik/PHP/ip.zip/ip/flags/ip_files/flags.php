<?
require 'ip.php';
$ip=$_SERVER['REMOTE_ADDR'];
$two_letter_country_code=ip_info("$ip", "Country Code");


//header('Content-type: image/gif');
$file_to_check="flags/$two_letter_country_code.gif";
if (file_exists($file_to_check)){
                print "<img src=$file_to_check width=30 height=15><br>";
                }else{
                print "<img src=flags/noflag.gif width=30 height=15><br>";
                }
                
                

//$img_filename = 'flags/SI.gif';           
//header('Content-type: image/gif');
//$file_pointer = fopen($img_filename, 'rb');
//fpassthru($file_pointer);
//fclose($file_pointer);
//exit;
?> 