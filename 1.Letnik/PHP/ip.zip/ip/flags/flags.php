<?
require 'ip.php';
$ip=$_SERVER['REMOTE_ADDR'];
$two_letter_country_code=ip_info("$ip", "Country Code");


$file_to_check="ip_flags/$two_letter_country_code.png";
if (file_exists($file_to_check)){
    $fileOut = "ip_flags/$two_letter_country_code.png";
    //Set the content-type header as appropriate
    $imageInfo = getimagesize($fileOut);
    switch ($imageInfo[2]) {
        case IMAGETYPE_JPEG:
            header("Content-Type: image/jpg");
            break;
        case IMAGETYPE_GIF:
            header("Content-Type: image/gif");
            break;
        case IMAGETYPE_PNG:
            header("Content-Type: image/png");
            break;
       default:
            break;
    }

    // Set the content-length header
    header('Content-Length: ' . filesize($fileOut));

    // Write the image bytes to the client
    readfile($fileOut);

}else{
$fileOut = "flags/noflag.gif";
    //Set the content-type header as appropriate
    $imageInfo = getimagesize($fileOut);
    switch ($imageInfo[2]) {
        case IMAGETYPE_JPEG:
            header("Content-Type: image/jpg");
            break;
        case IMAGETYPE_GIF:
            header("Content-Type: image/gif");
            break;
        case IMAGETYPE_PNG:
            header("Content-Type: image/png");
            break;
       default:
            break;
    }

    // Set the content-length header
    header('Content-Length: ' . filesize($fileOut));

    // Write the image bytes to the client
    readfile($fileOut);
}
?> 